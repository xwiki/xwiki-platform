/*
 * Copyright 2004-2005 The Apache Software Foundation or its licensors,
 *                     as applicable.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.portals.graffito.jcr.query.impl;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.portals.graffito.jcr.mapper.Mapper;
import org.apache.portals.graffito.jcr.mapper.model.ClassDescriptor;
import org.apache.portals.graffito.jcr.query.Filter;
import org.apache.portals.graffito.jcr.query.Query;

/**
 * Default Query implementation 
 * 
 * @author <a href="mailto:christophe.lombart@sword-technologies.com">Christophe Lombart</a>
 *
 */
public class QueryImpl implements Query
{
		
	private Filter filter;
	
    ClassDescriptor classDescriptor;
    
    private ArrayList orderByExpressions = new ArrayList();

	/**
	 * Constructor 
	 * 
	 * @param filter
	 * @param mapper
	 */
	public QueryImpl(Filter filter, Mapper mapper) 
	{				
		this.filter = filter;
		classDescriptor = mapper.getClassDescriptorByClass(filter.getFilterClass());
	}

	/**
	 * @see org.apache.portals.graffito.jcr.query.Query#setFilter(org.apache.portals.graffito.jcr.query.Filter)
	 */
	public void setFilter(Filter filter)
	{
		this.filter = filter;
	}

	/**
	 * @see org.apache.portals.graffito.jcr.query.Query#getFilter()
	 */
	public Filter getFilter()
	{
        return this.filter;
	}

	public void addOrderByDescending(String fieldNameAttribute)
	{
		orderByExpressions.add("@" + this.getJcrFieldName(fieldNameAttribute) + " descending");
	}

	/**
	 * 
	 * @see org.apache.portals.graffito.jcr.query.Query#addOrderByAscending(java.lang.String)
	 */
	public void addOrderByAscending(String fieldNameAttribute)
	{
		orderByExpressions.add("@" + this.getJcrFieldName(fieldNameAttribute) + " ascending");
	}
	
	public String getOrderByExpression()
	{
		
		if (orderByExpressions.size() == 0)
		{
		   return "";	
		}
		
		String orderByExpression = "order by ";
		Iterator iterator   = orderByExpressions.iterator();
		int count=1;
		while (iterator.hasNext())
		{
			   if (count > 1)
			   {
				   orderByExpression += " , ";
			   }
			   orderByExpression+= (String) iterator.next();
			   count++;
		}
		
		return orderByExpression;
	}
	
	
	private String getJcrFieldName(String fieldAttribute)
	{
		
		return classDescriptor.getJcrName(fieldAttribute);
	    	
	}

}
